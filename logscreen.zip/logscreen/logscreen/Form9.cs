﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace logscreen
{
    
    public partial class Form9 : Form
    {
        string conString = @"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True";
        connection obj = new connection();
        public Form9()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'machine1DataSet12.Table12' table. You can move, or remove it, as needed.
            this.table12TableAdapter.Fill(this.machine1DataSet12.Table12);
            // TODO: This line of code loads data into the 'machine1DataSet5.Table5' table. You can move, or remove it, as needed.
           // this.table5TableAdapter.Fill(this.machine1DataSet5.Table5);

        }
        public void displayvalue()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlDataAdapter sdf = new SqlDataAdapter("select * from table12", con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }
        public void searchdata(string search)
        {
            SqlConnection con = new SqlConnection(conString);
            string query = "select * from table12 where [bill no] like '%" + search + "%'";
            SqlDataAdapter sdf = new SqlDataAdapter(query, con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }


        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox1.Text == "" || textBox3.Text == ""  )
            {
                MessageBox.Show("Null values");
            }
            else
            {
                try
                {
                    obj.execute("INSERT INTO Table12 VALUES('" + textBox2.Text + "', '" + textBox1.Text + "' ,'" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "', '" + textBox3.Text + "')");
                    MessageBox.Show("inserted");
                    this.machine1DataSet12.Table12.Clear();
                    this.table12TableAdapter.Fill(this.machine1DataSet12.Table12);



                }
                catch (Exception ee)
                {
                    MessageBox.Show("error");
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox1.Clear();
            textBox3.Clear();
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    if (!row.IsNewRow)
                        dataGridView1.Rows.Remove(row);
                }

                obj.execute("delete from Table12 where [bill no]='" + textBox2.Text+"'");

                MessageBox.Show("deleted");
                this.machine1DataSet12.Table12.Clear();
                this.table12TableAdapter.Fill(this.machine1DataSet12.Table12);

            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox4.Text = row.Cells[0].Value.ToString();
                textBox2.Text = row.Cells[1].Value.ToString();
                textBox1.Text = row.Cells[2].Value.ToString();
                dateTimePicker1.Value = DateTime.ParseExact(row.Cells[3].Value.ToString(), "dd/MM/yyyy", null);
                textBox3.Text = row.Cells[4].Value.ToString();
                


            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {


                obj.execute(" update Table12 set purpose ='" + textBox1.Text + "', date='" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "',amount ='" + textBox3.Text + "' where [bill no]='" + textBox2.Text+"'");
                MessageBox.Show("updated");


                this.machine1DataSet12.Table12.Clear();
                this.table12TableAdapter.Fill(this.machine1DataSet12.Table12);



            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView1[3, dataGridView1.Rows.Count - 1].Value = "total";
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[4].Style.BackColor = Color.Yellow;
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[4].Style.ForeColor = Color.Red;

            decimal tot = 0;
            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            {
                var value = dataGridView1.Rows[i].Cells[4].Value;
                if (value != DBNull.Value)
                {
                    tot += Convert.ToDecimal(value);

                }

            }
            if (tot == 0)
            {

            }
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[4].Value = tot.ToString();
            MessageBox.Show("total calculated");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelapp = new Microsoft.Office.Interop.Excel.Application();
                xcelapp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xcelapp.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;

                }
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value != null)
                        {
                            xcelapp.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                        }

                    }
                }
                xcelapp.Columns.AutoFit();
                xcelapp.Visible = true;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form15 f1 = new Form15();
            f1.Show();
            this.Hide();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            searchdata(textBox5.Text);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (DateTime.Today < dateTimePicker1.Value)
            {
                dateTimePicker1.Value = DateTime.Today;
            }
        }
    }
}
