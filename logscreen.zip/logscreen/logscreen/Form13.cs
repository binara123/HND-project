﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace logscreen
{
    public partial class Form13 : Form
    {
        connection obj = new connection();

        static int no_days = 0; // get total number of days

        public Form13()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            string sdate = dateTimePicker1.Value.Date.ToString("yyyyMMdd");
            string edate = dateTimePicker2.Value.Date.ToString("yyyyMMdd");

            string q = "SELECT distinct * FROM  ( SELECT * FROM ( SELECT *, cast((concat (substring( replace (date,'/',''),5,4),substring( replace (date,'/',''),3,2),substring( replace (date,'/',''),1,2))) as int) as dmy FROM Tablea) t1 WHERE dmy>=" + sdate + " AND [emp no]='"+textBox1.Text+"' ) t2 WHERE dmy<=" + edate;
            SqlDataAdapter sdf = new SqlDataAdapter(q, con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
        }

        private void Form13_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'machine1DataSet22.Tablea' table. You can move, or remove it, as needed.
            this.tableaTableAdapter.Fill(this.machine1DataSet22.Tablea);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1[2, dataGridView1.Rows.Count - 1].Value = "total";
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[2].Style.BackColor = Color.Yellow;
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[2].Style.ForeColor = Color.Red;

            decimal tot = 0;
            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            {
                var value = dataGridView1.Rows[i].Cells[2].Value;
                if (value != DBNull.Value)
                {
                    tot += Convert.ToDecimal(value);

                }

            }
            if (tot == 0)
            {

            }
            no_days = int.Parse(tot.ToString());
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[2].Value = tot.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

           
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            textBox3.Text = (no_days * double.Parse(textBox2.Text)).ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True");
            con.Open();
            if(textBox1.Text!="")
            {
                SqlCommand cmd = new SqlCommand("select [day salary] AS dwage from table20  where [user id] =@uid", con);
                cmd.Parameters.AddWithValue("@uid",textBox1.Text);
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    textBox2.Text = da["dwage"].ToString();
                }
                con.Close();
            }
        }
    }
}
