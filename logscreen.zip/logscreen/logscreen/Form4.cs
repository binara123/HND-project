﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace logscreen
{
    public partial class Form4 : Form
    {
        connection con = new connection();
        loginuser u = new loginuser();

        public bool textuser { get; private set; }
        public Form4()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LOGIN_Click(object sender, EventArgs e)
        {

            string uname = textusername.Text;
            string dbpwd = "";
            string curpwd = textpassword.Text;
            string utype = "";

            SqlDataReader r = con.view("select * from table21 where email='" + uname + "'");

            while (r.Read())
            {
                dbpwd = r["password"].ToString();
                utype = r["user type"].ToString();
            }
           if(textusername.Text !="" && textpassword.Text == dbpwd && (utype== "Manager"))
            {
                MessageBox.Show("the username and password is correct");
                loginuser.Usr = uname;

                new Form5().Show();
                this.Hide();
            }
           else
            {
                MessageBox.Show("the username or password is incorrect");
            }
           
            }

        private void label2_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 f1 = new Form3();
            f1.Show();
            this.Hide();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
    }

