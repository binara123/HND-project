﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace logscreen
{
    public partial class Form12 : Form
    {
        string conString = @"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True";
        connection obj = new connection();
        loginuser u = new loginuser();

        static bool vmail = true;
        public Form12()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.Show();
            this.Hide();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'machine1DataSet20.Table20' table. You can move, or remove it, as needed.
            this.table20TableAdapter.Fill(this.machine1DataSet20.Table20);
            // TODO: This line of code loads data into the 'machine1DataSet19.Table19' table. You can move, or remove it, as needed.
            //this.table19TableAdapter.Fill(this.machine1DataSet19.Table19);
            // TODO: This line of code loads data into the 'machine1DataSet18.Table18' table. You can move, or remove it, as needed.
            // this.table18TableAdapter.Fill(this.machine1DataSet18.Table18);


            SqlConnection con = new SqlConnection(conString);
            con.Open();

            SqlDataAdapter sdf = new SqlDataAdapter("select * from table20 order by [password] desc", con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            dataGridView1.Columns[4].Visible = false;
            con.Close();
        }
        public void displayvalue()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlDataAdapter sdf = new SqlDataAdapter("select * from table20", con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }
        public void searchdata(string search)
        {
            SqlConnection con = new SqlConnection(conString);
            string query = "select * from table20 where [user id] like '%" + search + "%'";
            SqlDataAdapter sdf = new SqlDataAdapter(query, con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "" || textBox3.Text == "" || comboBox1.Text == "" || textBox2.Text == "" || textBox4.Text == "" || textBox7.Text == "" || textBox1.Text== "" || vmail == false)
            {
                MessageBox.Show("Null values or invalide mail address");
            }
            else
            {
                try
                {
                    obj.execute("INSERT INTO Table20 VALUES('" + textBox7.Text + "',  '" + textBox4.Text + "','" + textBox2.Text + "', '" + textBox5.Text + "','" + textBox3.Text + "','" + textBox1.Text + "','" + comboBox1.Text + "','" + textBox6.Text + "')");
                    MessageBox.Show("inserted");
                    this.machine1DataSet20.Table20.Clear();
                    this.table20TableAdapter.Fill(this.machine1DataSet20.Table20);


                }
                catch (Exception ee)
                {
                    MessageBox.Show("error");
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    if (!row.IsNewRow)
                        dataGridView1.Rows.Remove(row);
                }

                obj.execute("delete from Table20 where [user id]='" + textBox7.Text + "'");

                MessageBox.Show("deleted");
                this.machine1DataSet20.Table20.Clear();
                this.table20TableAdapter.Fill(this.machine1DataSet20.Table20);

            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox7.Text = row.Cells[0].Value.ToString();
                textBox4.Text = row.Cells[1].Value.ToString();
                textBox2.Text = row.Cells[2].Value.ToString();
                textBox5.Text = row.Cells[3].Value.ToString();
                textBox3.Text = row.Cells[4].Value.ToString();
                textBox1.Text = row.Cells[5].Value.ToString();
                comboBox1.Text = row.Cells[6].Value.ToString();
                textBox6.Text = row.Cells[7].Value.ToString();
                // dateTimePicker1.Text = row.Cells[2].Value.ToString();

                // dateTimePicker2.Text = row.Cells[5].Value.ToString();

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string cusr = loginuser.Usr;

            if (cusr == textBox5.Text)
            {

                try
                {


                    obj.execute(" update Table20 set [first name]='" + textBox4.Text + "',[user type]='" + comboBox1.Text + "',[last name]= '" + textBox2.Text + "',[password]='" + textBox3.Text + "',[email]='" + textBox5.Text + "',[day salary]='" + textBox6.Text + "',[contact]='" + textBox1.Text + "' where [user id]='" + textBox7.Text + "'");
                    MessageBox.Show("updated");


                    this.machine1DataSet20.Table20.Clear();
                    this.table20TableAdapter.Fill(this.machine1DataSet20.Table20);
                }
                catch (Exception ee)
                {
                    MessageBox.Show("error");
                }
            }
            else
            {
                MessageBox.Show("No permission");
            }
        }

        private void textBox5_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[com]{2,9})$";
            if (Regex.IsMatch(textBox5.Text, pattern))
            {
                vmail = true;
                errorProvider1.Clear();

            }
            else
            {
                vmail = false;
                errorProvider1.SetError(this.textBox5, "please enter valid email address");
                return;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Regex ex = new Regex(@"^[0-9]{10}$");
            if (ex.IsMatch(textBox1.Text))
            {
                textBox1.BackColor = System.Drawing.Color.LightGreen;
            }
            else

            {

                textBox1.BackColor = System.Drawing.Color.Red;

            }
        }

        private void dataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
           // if (e.ColumnIndex == 4 && e.Value != null) ;
            {
          //      e.Value = new string('*', e.Value.ToString().Length);
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            searchdata(textBox8.Text);
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelapp = new Microsoft.Office.Interop.Excel.Application();
                xcelapp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xcelapp.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;

                }
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value != null)
                        {
                            xcelapp.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                        }

                    }
                }
                xcelapp.Columns.AutoFit();
                xcelapp.Visible = true;
            }
        }
    }
}
