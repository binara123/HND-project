﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.Sql;
using System.Data.SqlClient;

namespace logscreen
{
    class connection
    {
        string conString = @"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True";

        public void execute(string q)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand mycmd = new SqlCommand(q, con);
            mycmd.ExecuteNonQuery();
            con.Close();
        }

        public SqlDataReader view(string q)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand mycmd = new SqlCommand(q, con);
            SqlDataReader myreader = mycmd.ExecuteReader();
            return myreader;
        }
    }
}
