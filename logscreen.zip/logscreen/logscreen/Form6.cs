﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace logscreen
{
    public partial class Form6 : Form
    {
        string conString = @"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True";
        connection obj = new connection();

        static bool vmail = true;
        public Form6()
        {
            InitializeComponent();
            displayvalue();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

       

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
          
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {/*
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                    textBox5.Text = row.Cells[0].Value.ToString();
                    comboBox2.Text = row.Cells[1].Value.ToString();
                // dateTimePicker1.Text = row.Cells[2].Value.ToString();
                dateTimePicker1.Value = DateTime.ParseExact(row.Cells[2].Value.ToString(), "dd/MM/yyyy", null);
                    textBox3.Text = row.Cells[3].Value.ToString();
                    textBox4.Text = row.Cells[4].Value.ToString();
                // dateTimePicker2.Text = row.Cells[5].Value.ToString();
                dateTimePicker2.Value = DateTime.ParseExact(row.Cells[5].Value.ToString(), "dd/MM/yyyy", null);
            }
           */
        }

        private void Form6_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'machine1DataSet14.Table14' table. You can move, or remove it, as needed.
            this.table14TableAdapter.Fill(this.machine1DataSet14.Table14);
            // TODO: This line of code loads data into the 'machine1DataSet10.Table10' table. You can move, or remove it, as needed.
            //this.table10TableAdapter.Fill(this.machine1DataSet10.Table10);
            // TODO: This line of code loads data into the 'machine1DataSet9.Table9' table. You can move, or remove it, as needed.
            //this.table9TableAdapter.Fill(this.machine1DataSet9.Table9);
            // TODO: This line of code loads data into the 'machine1DataSet1.Table1' table. You can move, or remove it, as needed.
            //this.table1TableAdapter1.Fill(this.machine1DataSet1.Table1);

        }
        public void displayvalue()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlDataAdapter sdf = new SqlDataAdapter("select * from table14", con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView2.DataSource = sd;
            con.Close();
        }
        public void searchdata(string search)
        {
            SqlConnection con = new SqlConnection(conString);
            string query = "select * from table14 where [machine no] like '%" + search + "%'";
            SqlDataAdapter sdf = new SqlDataAdapter(query, con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView2.DataSource = sd;
            con.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
            try
            {


                obj.execute(" update Table14 set [machine type]='"+comboBox2.Text+"',[warrenty period]='"+comboBox3.Text+"',[reminder send to]= '"+textBox2.Text+"' ,[manufacture date]='"+dateTimePicker1.Value.Date.ToString("dd/MM/yyyy")+"',[reminder shedule date]='"+ dateTimePicker2.Value.Date.ToString("dd/MM/yyyy")+"',[price]='"+textBox3.Text+"' where [machine no]='"+textBox5.Text+"'");
                MessageBox.Show("updated");
         

                this.machine1DataSet14.Table14.Clear();
                this.table14TableAdapter.Fill(this.machine1DataSet14.Table14);
                MailMessage mail = new MailMessage();
                SmtpClient smtpserver = new SmtpClient("smtp.gmail.com");
                mail.From = new MailAddress("binara.pathiratna@gmail.com");
                mail.To.Add(textBox2.Text);
                mail.Subject = ("update machine details");
                mail.Body = ("machine no = " + textBox5.Text + ", machine type =" + comboBox2.Text + ",warrenty period =" + comboBox3.Text + ", manufacture date =" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + ",reminder shedule date =" + dateTimePicker2.Value.Date.ToString("dd/MM/yyyy") + ",price =" + textBox3.Text + "");

                smtpserver.Port = 587;
                smtpserver.Credentials = new System.Net.NetworkCredential("binara.pathiratna@gmail.com", "binara@123");
                smtpserver.EnableSsl = true;
                smtpserver.Send(mail);
                MessageBox.Show("mail sent");




            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }

        }

        private void table1BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dataGridView2.SelectedRows)
                {
                    if (!row.IsNewRow)
                        dataGridView2.Rows.Remove(row);
                }

                obj.execute("delete from Table14 where [machine no]='" + textBox5.Text+"'" );
                
                MessageBox.Show("deleted");
                this.machine1DataSet14.Table14.Clear();
                this.table14TableAdapter.Fill(this.machine1DataSet14.Table14);

            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }


        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
           


        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "" || textBox3.Text == "" || comboBox3.Text == ""||textBox2.Text==""||vmail==false)
            {
                MessageBox.Show("Null values or invalide mail address");
            }
            else
            {
                try
                {
                    obj.execute("INSERT INTO Table14 VALUES('" + textBox5.Text + "', '" + comboBox2.SelectedItem.ToString() + "', '" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "', '" + textBox3.Text + "', '" + comboBox3.Text + "','"+textBox2.Text +"', '" + dateTimePicker2.Value.Date.ToString("dd/MM/yyyy") + "')");
                    
                    this.machine1DataSet14.Table14.Clear();
                    this.table14TableAdapter.Fill(this.machine1DataSet14.Table14);
                    MessageBox.Show("inserted");
                    button9_Click_1(sender, e);

                }
                catch (Exception ee)
                {
                    MessageBox.Show("error");
                }
               

            }
            //table1TableAdapter1.Update(machine1DataSet1.Table1);
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            textBox5.Clear();
            textBox3.Clear();
            textBox2.Clear();

            DataTable dt = machine1DataSet14.Table14;


            dataGridView2.DataSource=dt;

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.Show();
            this.Hide();
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView2.Rows[e.RowIndex];
                textBox1.Text = row.Cells[0].Value.ToString();
                textBox5.Text = row.Cells[1].Value.ToString();
                comboBox2.Text = row.Cells[2].Value.ToString();
                // dateTimePicker1.Text = row.Cells[2].Value.ToString();
                dateTimePicker1.Value = DateTime.ParseExact(row.Cells[3].Value.ToString(), "dd/MM/yyyy", null);
                textBox3.Text = row.Cells[4].Value.ToString();
                comboBox3.Text = row.Cells[5].Value.ToString();
                textBox2.Text = row.Cells[6].Value.ToString();
                // dateTimePicker2.Text = row.Cells[5].Value.ToString();
                dateTimePicker2.Value = DateTime.ParseExact(row.Cells[7].Value.ToString(), "dd/MM/yyyy", null);
            }
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[com]{2,9})$";
            if (Regex.IsMatch(textBox2.Text, pattern))
            {
                vmail = true;
                errorProvider1.Clear();

            }
            else
            {
                vmail = false;
                errorProvider1.SetError(this.textBox2, "please enter valid email address");
                return;
            }
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            MailMessage mail = new MailMessage();
            SmtpClient smtpserver = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("binara.pathiratna@gmail.com");
            mail.To.Add(textBox2.Text);
            mail.Subject = ("machine details");
            mail.Body =(" machine no = "+textBox5.Text+ " ,machine type =" + comboBox2.Text + ",warrenty period =" + comboBox3.Text + ", manufacture date =" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + ",reminder shedule date =" + dateTimePicker2.Value.Date.ToString("dd/MM/yyyy") + ",price =" + textBox3.Text + "");

            smtpserver.Port = 587;
            smtpserver.Credentials = new System.Net.NetworkCredential("binara.pathiratna@gmail.com", "binara@123");
            smtpserver.EnableSsl = true;
            smtpserver.Send(mail);
            MessageBox.Show("mail sent");


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click_1(object sender, EventArgs e)
        {

            if (dataGridView2.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelapp = new Microsoft.Office.Interop.Excel.Application();
                xcelapp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView2.Columns.Count + 1; i++)
                {
                    xcelapp.Cells[1, i] = dataGridView2.Columns[i - 1].HeaderText;

                }
                for (int i = 0; i < dataGridView2.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView2.Columns.Count; j++)
                    {
                        if (dataGridView2.Rows[i].Cells[j].Value != null)
                        {
                            xcelapp.Cells[i + 2, j + 1] = dataGridView2.Rows[i].Cells[j].Value.ToString();
                        }

                    }
                }
                xcelapp.Columns.AutoFit();
                xcelapp.Visible = true;
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           searchdata(textBox4.Text);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (DateTime.Today < dateTimePicker1.Value)
            {
                dateTimePicker1.Value = DateTime.Today;
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            if (DateTime.Today > dateTimePicker2.Value)
            {
                dateTimePicker2.Value = DateTime.Today;
            }
        }
    }
}
