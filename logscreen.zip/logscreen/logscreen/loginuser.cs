﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace logscreen
{
    class loginuser
    {
        private static string _usr;

        public static string Usr
        {
            get
            {
                return _usr;
            }
            set
            {
                _usr = value;
            }
        }

    }
}
