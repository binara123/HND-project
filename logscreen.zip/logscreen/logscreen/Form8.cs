﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace logscreen
{
    public partial class Form8 : Form
    {
        connection obj = new connection();
        static int c = 0;
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.Show();
            this.Hide();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            c++;

            if (c == 2)
            {
                try
                {
                    obj.execute("INSERT INTO Tablea VALUES('" + textBox1.Text + "', '" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "',1)");
                   // MessageBox.Show("inserted");
                    


                }
                catch (Exception ee)
                {
                    MessageBox.Show("error");
                }
            }
            else if (c == 4)
            {
                textBox1.Clear();
                c = 0;
                timer1.Enabled = false;
            }
        }
    }
}
