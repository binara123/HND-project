﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Text.RegularExpressions;

namespace logscreen
{
    public partial class Form14 : Form
    {
        string conString = @"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True";
        static bool vmail = true;
        connection obj = new connection();
        public Form14()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "" || textBox3.Text == ""|| textBox4.Text == "" ||vmail==false)
            {
                MessageBox.Show("Null values or invalide mail address");
            }
            else
            {
                try
                {
                    obj.execute("INSERT INTO Table15 VALUES('" + textBox2.Text + "', '" + comboBox1.SelectedItem.ToString() + "', '" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "', '" + textBox3.Text + "', '" + comboBox2.Text + "','"+textBox4.Text+"', '" + dateTimePicker2.Value.Date.ToString("dd/MM/yyyy") + "')");
                    MessageBox.Show("inserted");
                    this.machine1DataSet15.Table15.Clear();
                    this.table15TableAdapter.Fill(this.machine1DataSet15.Table15);
                    button6_Click(sender, e);




                }
                catch (Exception ee)
                {
                    MessageBox.Show("error");
                }

            }
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'machine1DataSet15.Table15' table. You can move, or remove it, as needed.
            this.table15TableAdapter.Fill(this.machine1DataSet15.Table15);
            // TODO: This line of code loads data into the 'machine1DataSet13.Table13' table. You can move, or remove it, as needed.
            //this.table13TableAdapter.Fill(this.machine1DataSet13.Table13);
            // TODO: This line of code loads data into the 'machine1DataSet6.Table6' table. You can move, or remove it, as needed.
           // this.table6TableAdapter.Fill(this.machine1DataSet6.Table6);

        }
        public void displayvalue()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlDataAdapter sdf = new SqlDataAdapter("select * from table15", con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }
        public void searchdata(string search)
        {
            SqlConnection con = new SqlConnection(conString);
            string query = "select * from table15 where [machine no] like '%" + search + "%'";
            SqlDataAdapter sdf = new SqlDataAdapter(query, con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            textBox2.Clear();
            textBox3.Clear();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {


                obj.execute(" update Table15 set [machine type]='" + comboBox1.Text + "',[warrenty period]='" + comboBox2.Text + "',[manufacture date]='" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "',[reminder shedule date]='" + dateTimePicker2.Value.Date.ToString("dd/MM/yyyy") + "',[reminder send to]= '" + textBox4.Text + "',[price]='" + textBox3.Text + "' where [machine no]='" + textBox2.Text+"'");
                MessageBox.Show("updated");


                this.machine1DataSet15.Table15.Clear();
                this.table15TableAdapter.Fill(this.machine1DataSet15.Table15);
                MailMessage mail = new MailMessage();
                SmtpClient smtpserver = new SmtpClient("smtp.gmail.com");
                mail.From = new MailAddress("binara.pathiratna@gmail.com");
                mail.To.Add(textBox4.Text);
                mail.Subject = ("update machine details");
                mail.Body = (" machine no = " + textBox2.Text + " ,machine type =" + comboBox1.Text + ",warrenty period =" + comboBox2.Text + ", manufacture date =" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + ",reminder shedule date =" + dateTimePicker2.Value.Date.ToString("dd/MM/yyyy") + ",price =" + textBox3.Text + "");

                smtpserver.Port = 587;
                smtpserver.Credentials = new System.Net.NetworkCredential("binara.pathiratna@gmail.com", "binara@123");
                smtpserver.EnableSsl = true;
                smtpserver.Send(mail);
                MessageBox.Show("mail sent");



            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox1.Text = row.Cells[0].Value.ToString();
                textBox2.Text = row.Cells[1].Value.ToString();
                comboBox1.Text = row.Cells[2].Value.ToString();
                // dateTimePicker1.Text = row.Cells[2].Value.ToString();
                dateTimePicker1.Value = DateTime.ParseExact(row.Cells[3].Value.ToString(), "dd/MM/yyyy", null);
                textBox3.Text = row.Cells[4].Value.ToString();
                comboBox2.Text = row.Cells[5].Value.ToString();
                textBox4.Text = row.Cells[6].Value.ToString();
                // dateTimePicker2.Text = row.Cells[5].Value.ToString();
                dateTimePicker2.Value = DateTime.ParseExact(row.Cells[7].Value.ToString(), "dd/MM/yyyy", null);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 f1 = new Form5();
            f1.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            MailMessage mail = new MailMessage();
            SmtpClient smtpserver = new SmtpClient("smtp.gmail.com");
            mail.From = new MailAddress("binara.pathiratna@gmail.com");
            mail.To.Add(textBox4.Text);
            mail.Subject = ("machine details");
            mail.Body = (" machine no = " + textBox2.Text + " ,machine type =" + comboBox1.Text + ",warrenty period =" + comboBox2.Text + ", manufacture date =" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + ",reminder shedule date =" + dateTimePicker2.Value.Date.ToString("dd/MM/yyyy") + ",price =" + textBox3.Text + "");

            smtpserver.Port = 587;
            smtpserver.Credentials = new System.Net.NetworkCredential("binara.pathiratna@gmail.com", "binara@123");
            smtpserver.EnableSsl = true;
            smtpserver.Send(mail);
            MessageBox.Show("mail sent");
        }

        private void textBox4_Leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[com]{2,9})$";
            if (Regex.IsMatch(textBox4.Text, pattern))
            {
                vmail = true;
                errorProvider1.Clear();

            }
            else
            {
                vmail = false;
                errorProvider1.SetError(this.textBox4, "please enter valid email address");
                return;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelapp = new Microsoft.Office.Interop.Excel.Application();
                xcelapp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xcelapp.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;

                }
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if (dataGridView1.Rows[i].Cells[j].Value != null)
                        {
                            xcelapp.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                        }

                    }
                }
                xcelapp.Columns.AutoFit();
                xcelapp.Visible = true;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            searchdata(textBox5.Text);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (DateTime.Today < dateTimePicker1.Value)
            {
                dateTimePicker1.Value = DateTime.Today;
            }
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            if (DateTime.Today > dateTimePicker2.Value)
            {
                dateTimePicker2.Value = DateTime.Today;
            }
        }
    }
}
