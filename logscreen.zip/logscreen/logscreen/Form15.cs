﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace logscreen
{
    public partial class Form15 : Form
    {
        string conString = @"Data Source=DESKTOP-P5J59RT\SQLEXPRESS;Initial Catalog=machine1;Integrated Security=True";
        connection obj = new connection();
        public Form15()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form9 f1 = new Form9();
            f1.Show();
            this.Hide();
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'machine1DataSet11.Table11' table. You can move, or remove it, as needed.
            this.table11TableAdapter.Fill(this.machine1DataSet11.Table11);
            // TODO: This line of code loads data into the 'machine1DataSet4.Table4' table. You can move, or remove it, as needed.
            //this.table4TableAdapter.Fill(this.machine1DataSet4.Table4);
            // TODO: This line of code loads data into the 'machine1DataSet3.Table3' table. You can move, or remove it, as needed.
           // this.table3TableAdapter.Fill(this.machine1DataSet3.Table3);

        }
        public void displayvalue()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlDataAdapter sdf = new SqlDataAdapter("select * from table11", con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }
        public void searchdata(string search)
        {
            SqlConnection con = new SqlConnection(conString);
            string query = "select * from table11 where [bill no] like '%" + search + "%'";
            SqlDataAdapter sdf = new SqlDataAdapter(query, con);
            DataTable sd = new DataTable();
            sdf.Fill(sd);
            dataGridView1.DataSource = sd;
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox3.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Null values");
            }
            else
            {
                try
                {
                    obj.execute("INSERT INTO Table11 VALUES('" + textBox1.Text + "', '"+ textBox3.Text +"' ,'" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "', '" + textBox2.Text + "' )");
                    MessageBox.Show("inserted");
                    this.machine1DataSet11.Table11.Clear();
                    this.table11TableAdapter.Fill(this.machine1DataSet11.Table11);



                }
                catch (Exception ee)
                {
                    MessageBox.Show("error");
                }

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox3.Clear();
            textBox2.Clear();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    if (!row.IsNewRow)
                        dataGridView1.Rows.Remove(row);
                }

                obj.execute("delete from Table11 where [bill no]='" + textBox1.Text+"'");

                MessageBox.Show("deleted");
                this.machine1DataSet11.Table11.Clear();
                this.table11TableAdapter.Fill(this.machine1DataSet11.Table11);

            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                textBox5.Text = row.Cells[0].Value.ToString();
                textBox1.Text = row.Cells[1].Value.ToString();
                textBox3.Text = row.Cells[2].Value.ToString();
                dateTimePicker1.Value = DateTime.ParseExact(row.Cells[3].Value.ToString(), "dd/MM/yyyy", null);
                textBox2.Text = row.Cells[4].Value.ToString();
                


            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {


                obj.execute(" update Table11 set purpose ='" + textBox3.Text + "', date='" + dateTimePicker1.Value.Date.ToString("dd/MM/yyyy") + "',amount ='" + textBox2.Text + "' where [bill no]='" + textBox1.Text +"'");
                MessageBox.Show("updated");


                this.machine1DataSet11.Table11.Clear();
                this.table11TableAdapter.Fill(this.machine1DataSet11.Table11);



            }
            catch (Exception ee)
            {
                MessageBox.Show("error");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            dataGridView1[3, dataGridView1.Rows.Count - 1].Value = "total";
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[4].Style.BackColor = Color.Yellow;
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[4].Style.ForeColor = Color.Red;

            decimal tot = 0;
            for(int i = 0; i < dataGridView1.RowCount -1; i++)
            {
                var value = dataGridView1.Rows[i].Cells[4].Value;
                if(value != DBNull.Value)
            {
                tot += Convert.ToDecimal(value);
                    
            }

            }  
           if(tot==0)
            {

            }
            dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[4].Value = tot.ToString();
            MessageBox.Show("total calculated");
        }

        private void button6_Click(object sender, EventArgs e)
        {

            if (dataGridView1.Rows.Count > 0)
            {
                Microsoft.Office.Interop.Excel.Application xcelapp = new Microsoft.Office.Interop.Excel.Application();
                xcelapp.Application.Workbooks.Add(Type.Missing);

                for (int i = 1; i < dataGridView1.Columns.Count + 1; i++)
                {
                    xcelapp.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;

                }
                for (int i = 0; i < dataGridView1.Rows.Count ; i++)
                {
                    for (int j = 0; j < dataGridView1.Columns.Count; j++)
                    {
                        if(dataGridView1.Rows[i].Cells[j].Value!=null)
                        {
                            xcelapp.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                        }
                        
                    }
                }
                xcelapp.Columns.AutoFit();
                xcelapp.Visible = true;
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.Show();
            this.Hide();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            searchdata(textBox4.Text);
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            if (DateTime.Today < dateTimePicker1.Value)
            {
                dateTimePicker1.Value = DateTime.Today;
            }
        }
    }
}
