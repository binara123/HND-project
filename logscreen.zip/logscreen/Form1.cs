﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Sql;
using System.Data.SqlClient;

namespace logscreen
{
    public partial class Form1 : Form
    {
        connection con = new connection();
        loginuser u = new loginuser();

        public bool txtusern { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LOGIN_Click(object sender, EventArgs e)
        {
            string uname = txtusername.Text;
            string dbpwd = "";
            string curpwd = txtpassword.Text;
            string utype = "";
            

            SqlDataReader r = con.view("SELECT * FROM Table20 WHERE email='"+uname+"'");

            while(r.Read())
            {
                dbpwd = r["password"].ToString();
                utype = r["user type"].ToString();
            }


            if (txtusername.Text != "" && txtpassword.Text == dbpwd && (utype== "Admin"))
            { 
                MessageBox.Show("the username and password is correct");
                loginuser.Usr = uname;


                new Form2().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("the username or password is incorrect");

            }



                

            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            txtusername.Clear();
            txtpassword.Clear();
            txtusername.Focus();  
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();  
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 f1 = new Form3();
            f1.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
